# -*- coding: utf-8 -*-
"""
1688「1688 市场」前10页抓取（mtop 签名接口版，无需浏览器）
用法：python tools/1688_scraper.py <关键词>
- 关键词从命令行参数读取，缺省用默认值
- 调用 h5api.m.1688.com 的 mtop.relationrecommend.WirelessRecommend.recommend (appId=32517)
- 固定抓前 10 页，每页 60 条；自动处理 _m_h5_tk token 轮换、限流退避重试、去重；翻页间隔 12~25s 规避限流
- Cookie 读取顺序：tools/1688_cookie.txt（k=v; k2=v2 字符串）→ tools/cookies.json（EditThisCookie 数组）
- 输出字段：排名、标题、商品超链接、店铺名、封面图、价格
  -> tools/_1688_top10.json（哪个字段抓不到就置 null，不落库）
- 全程写 tools/_1688_progress.json 供前端进度条轮询
"""
import hashlib
import json
import os
import random
import re
import string
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from http.cookiejar import CookieJar

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

DEFAULT_KEYWORD = "汽车脚垫"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_JSON = os.path.join(BASE_DIR, "_1688_top10.json")
PROGRESS_FILE = os.path.join(BASE_DIR, "_1688_progress.json")
COOKIE_TXT = os.path.join(BASE_DIR, "1688_cookie.txt")
COOKIE_JSON = os.path.join(BASE_DIR, "cookies.json")

MAX_PAGES = 10  # 固定抓前 10 页

APP_KEY = "12574478"
API_NAME = "mtop.relationrecommend.WirelessRecommend.recommend"
API_PATH = "mtop.relationrecommend.wirelessrecommend.recommend"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

TAG_RE = re.compile(r"<[^>]+>")


def resolve_keyword():
    """抓取关键词：优先命令行参数，其次 1688_KEYWORD 环境变量，最后默认值"""
    if len(sys.argv) > 1 and sys.argv[1].strip():
        return sys.argv[1].strip()
    return (os.environ.get("1688_KEYWORD") or DEFAULT_KEYWORD).strip()


def log(*a):
    print(*a, flush=True)


def write_progress(status, done, total, keyword):
    """写进度文件，供后端 /status 接口读取"""
    try:
        with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
            json.dump({"status": status, "keyword": keyword, "done": done, "total": total},
                      f, ensure_ascii=False)
    except Exception:
        pass


def load_cookie_dict():
    """读取 1688 Cookie：优先 1688_cookie.txt（k=v; k2=v2），否则 cookies.json（EditThisCookie 数组）"""
    if os.path.exists(COOKIE_TXT):
        with open(COOKIE_TXT, encoding="utf-8") as f:
            s = f.read().strip()
        d = {}
        for part in s.split(";"):
            part = part.strip()
            if not part or "=" not in part:
                continue
            name, _, value = part.partition("=")
            if name.strip():
                d[name.strip()] = value.strip()
        return d
    if os.path.exists(COOKIE_JSON):
        with open(COOKIE_JSON, encoding="utf-8") as f:
            arr = json.load(f)
        if isinstance(arr, list):
            return {c["name"]: c["value"] for c in arr
                    if isinstance(c, dict) and c.get("name") and "value" in c}
    return {}


def rand_pageid(n=48):
    return "".join(random.choices(
        string.ascii_uppercase + string.ascii_lowercase + string.digits + "3456", k=n))


class MtopClient:
    def __init__(self, ck: dict):
        self.jar = CookieJar()
        import http.cookiejar as hc
        from urllib.request import HTTPCookieProcessor, build_opener
        for name, value in ck.items():
            c = hc.Cookie(version=0, name=name, value=value, port=None, port_specified=False,
                          domain=".1688.com", domain_specified=True, domain_initial_dot=True,
                          path="/", path_specified=True, secure=False, expires=None,
                          discard=True, comment=None, comment_url=None, rest={}, rfc2109=False)
            self.jar.set_cookie(c)
        self.opener = build_opener(HTTPCookieProcessor(self.jar))
        # 关键：pageId 每次运行只生成一次并全程复用（随机换 pageId 会导致服务端重排结果、翻页大量重复）
        self.page_id = rand_pageid()

    def _token(self):
        for c in self.jar:
            if c.name == "_m_h5_tk" and c.value:
                return c.value.split("_")[0]
        return ""

    def call(self, keywords, begin_page, page_size=60, retries=5):
        params_obj = {
            "keywords": keywords,
            "beginPage": begin_page,
            "pageSize": page_size,
            "method": "getOfferList",
            "verticalProductFlag": "pcmarket",
            "searchScene": "pcOfferSearch",
            "charset": "GBK",
            "pageId": self.page_id,
        }
        data_obj = {"appId": "32517",
                    "params": json.dumps(params_obj, ensure_ascii=False, separators=(",", ":"))}
        data = json.dumps(data_obj, ensure_ascii=False, separators=(",", ":"))

        for attempt in range(retries):
            token = self._token()
            t = str(int(time.time() * 1000))
            sign = hashlib.md5((token + "&" + t + "&" + APP_KEY + "&" + data).encode()).hexdigest()
            url = (f"https://h5api.m.1688.com/h5/{API_PATH}/2.0/?" + urllib.parse.urlencode({
                "jsv": "2.7.4", "appKey": APP_KEY, "t": t, "sign": sign,
                "api": API_NAME, "v": "2.0",
                "type": "originaljson", "dataType": "json", "data": data,
            }))
            req = urllib.request.Request(url, headers={
                "User-Agent": UA,
                "Referer": "https://s.1688.com/selloffer/offer_search.htm?keywords="
                           + urllib.parse.quote(keywords),
                "Accept": "application/json, text/plain, */*",
            })
            try:
                resp = self.opener.open(req, timeout=25)
                raw = resp.read().decode("utf-8", "ignore")
            except urllib.error.HTTPError as e:
                raw = e.read().decode("utf-8", "ignore")
            except Exception as e:
                if attempt < retries - 1:
                    time.sleep(5 + attempt * 5)
                    continue
                return None, str(e)

            try:
                j = json.loads(raw)
            except Exception:
                if attempt < retries - 1:
                    time.sleep(3)
                    continue
                return None, "非JSON响应"

            ret = j.get("ret") or []
            ret_str = ";".join(ret) if isinstance(ret, list) else str(ret)
            # token 类错误：token 可从响应自刷新，短退避后重试
            if "FAIL_SYS_TOKEN" in ret_str or "TOKEN_EMPTY" in ret_str:
                if attempt < retries - 1:
                    time.sleep(1.5)
                    continue
                return None, ret_str
            # 限流/被挤爆（FAIL_SYS_USER_VALIDATE / RGV587 / 被挤爆啦）：长退避后重试
            if "被挤爆" in ret_str or "RGV587" in ret_str or "FAIL_SYS_USER_VALIDATE" in ret_str:
                if attempt < retries - 1:
                    wait = 15 + attempt * 10 + random.uniform(0, 5)
                    log(f"    [限流] 退避 {wait:.0f}s 后重试 ({attempt + 1}/{retries})")
                    time.sleep(wait)
                    continue
                return None, ret_str
            # 其他 FAIL_SYS
            if "FAIL_SYS" in ret_str and "SUCCESS" not in ret_str:
                if attempt < retries - 1:
                    time.sleep(3)
                    continue
                return None, ret_str
            return j, None
        return None, "重试耗尽"


def _extract_image(d):
    """从 1688 item 的 data 里提取封面图 URL：多字段兜底 + 取首图 + 协议补全"""
    raw = ""
    # 常见字段名，按优先级
    for k in ("offerPicUrl", "odPicUrl", "imageUrl", "imgUrl", "picUrl", "mainPic", "image"):
        v = d.get(k)
        if isinstance(v, str) and v.strip():
            raw = v
            break
        if isinstance(v, dict):
            raw = v.get("imageUrl") or v.get("imgUrl") or v.get("picUrl") or v.get("url") or ""
            if raw:
                break
    # 兜底：扫描所有 key 名含 image/img/pic 的字符串字段
    if not raw:
        for k, v in d.items():
            if isinstance(v, str) and v.strip() and any(s in k.lower() for s in ("image", "img", "pic")):
                raw = v
                break
    # image 字段可能是 JSON 字符串，如 {"imageUrl":"//..."}
    if isinstance(raw, str) and raw.lstrip().startswith("{"):
        try:
            j = json.loads(raw)
            raw = j.get("imageUrl") or j.get("imgUrl") or j.get("picUrl") or j.get("url") or ""
        except Exception:
            pass
    if not isinstance(raw, str) or not raw.strip():
        return ""
    # 逗号分隔的多图，取第一张
    url = raw.split(",")[0].strip()
    if not url:
        return ""
    # 协议补全：// -> https://，http -> https（alicdn 支持 https）
    if url.startswith("//"):
        url = "https:" + url
    elif url.startswith("http://"):
        url = "https://" + url[7:]
    return url


def parse_offer(item):
    d = item.get("data") or {}
    title = TAG_RE.sub("", d.get("title") or "").strip()
    offer_id = str(d.get("offerId") or "")
    pi = d.get("priceInfo") or {}
    price_raw = ""
    if isinstance(pi, dict):
        price_raw = str(pi.get("price") or "")
        if not price_raw:
            pr = pi.get("priceRange") or []
            if isinstance(pr, list) and pr:
                price_raw = "-".join(str(x.get("price", "")) for x in pr if isinstance(x, dict))
    nums = re.findall(r"(\d+(?:\.\d+)?)", price_raw)
    nums = [float(n) for n in nums]
    price_min = min(nums) if nums else None
    price_max = max(nums) if len(nums) > 1 else price_min
    url = f"https://detail.1688.com/offer/{offer_id}.html" if offer_id else ""
    cover_image = _extract_image(d)
    shop = d.get("shop") or {}
    shop_name = shop.get("text", "") if isinstance(shop, dict) else ""
    return {
        "title": title,
        "price_raw": price_raw,
        "price_min": price_min,
        "price_max": price_max,
        "offer_id": offer_id,
        "url": url,
        "cover_image": cover_image,
        "shop_name": shop_name,
    }


def fmt_price(price_min, price_max):
    """价格区间格式化：单点返回 ¥X，区间返回 ¥min-max；缺失返回 None"""
    if price_min is None:
        return None
    def g(x):
        return "%g" % float(x)
    if price_max is not None and price_max != price_min:
        return "¥%s-%s" % (g(price_min), g(price_max))
    return "¥%s" % g(price_min)


def main():
    keyword = resolve_keyword()
    write_progress("running", 0, MAX_PAGES, keyword)

    ck = load_cookie_dict()
    if not ck:
        log("[错误] 缺少 1688 Cookie：请在前端「1688 市场」面板保存 Cookie，"
            "或提供 tools/1688_cookie.txt / tools/cookies.json")
        write_progress("error", 0, MAX_PAGES, keyword)
        return

    client = MtopClient(ck)
    log(f"[启动] 关键词={keyword} 目标页数={MAX_PAGES} Cookie={len(ck)}条")

    all_items, per_page = [], []
    for pg in range(1, MAX_PAGES + 1):
        j, err = None, None
        for page_try in range(4):
            j, err = client.call(keyword, pg)
            if not err:
                break
            log(f"[页{pg}] 第{page_try + 1}次请求失败: {err[:50]} → 退避60s重试")
            time.sleep(60)
        if err:
            log(f"[页{pg}] 单页多次重试仍失败，停止抓取")
            break
        try:
            offer = j["data"]["data"]["OFFER"]
            items = offer.get("items") or []
            has_more = offer.get("hasMore", True)
        except Exception:
            items, has_more = [], False
        # 首条商品原始字段名（仅第1页，便于排查图片字段）
        if pg == 1 and items:
            first_data = (items[0].get("data") or {}) if isinstance(items[0], dict) else {}
            log(f"[结构] 首条 data 字段 = {sorted(first_data.keys())}")
        # 不做销量过滤：有标题或商品ID即保留
        parsed = [p for p in (parse_offer(i) for i in items) if p.get("title") or p.get("offer_id")]
        for p in parsed:
            p["page"] = pg
        per_page.append(len(parsed))
        all_items.extend(parsed)
        log(f"[页{pg}/{MAX_PAGES}] 抓到 {len(parsed)} 条 (累计 {len(all_items)}) hasMore={has_more}")
        write_progress("running", pg, MAX_PAGES, keyword)
        if not has_more or not items:
            log("  -> 已到最后一页，停止")
            break
        if pg < MAX_PAGES:
            time.sleep(random.uniform(12, 25))

    # 去重
    seen, deduped = set(), []
    for it in all_items:
        key = (it["title"], it["offer_id"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(it)

    products = [
        dict(rank=i + 1,
             title=it["title"] or None,
             price=fmt_price(it["price_min"], it["price_max"]),
             image=it["cover_image"] or None,
             shop=it["shop_name"] or None,
             link=it["url"] or None)
        for i, it in enumerate(deduped)
    ]

    with_img = sum(1 for p in products if p.get("image"))
    if products:
        s = products[0]
        log(f"[样本] 首条 title={s['title']!r} image={s['image']!r}")
    log(f"[图片] {with_img}/{len(products)} 条抓到封面图")

    result = {
        "keyword": keyword,
        "count": len(products),
        "pages_crawled": len(per_page),
        "total_deduped": len(deduped),
        "per_page_counts": per_page,
        "products": products,
    }
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    write_progress("done", len(per_page), MAX_PAGES, keyword)
    log(f"[保存] {OUT_JSON} 共 {len(products)} 条（去重后）")


if __name__ == "__main__":
    main()
